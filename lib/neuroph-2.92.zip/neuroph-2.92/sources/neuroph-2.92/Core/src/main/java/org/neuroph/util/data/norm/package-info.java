/**
 * Provides data normalization techniques
 */
package org.neuroph.util.data.norm;
