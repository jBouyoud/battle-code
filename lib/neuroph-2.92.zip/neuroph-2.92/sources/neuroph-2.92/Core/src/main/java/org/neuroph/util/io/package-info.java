/**
 * Provides input/output adapters for file, JDBC, URL, stream
 */
package org.neuroph.util.io;
